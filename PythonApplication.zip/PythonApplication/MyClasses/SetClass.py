import logging
class SetClass:
    def __init__(self, Set):
        logging.basicConfig(format='Date-Time : %(asctime)s : - %(message)s', level = logging.INFO, 
                            filename = 'AppLogs.log',filemode = 'w')
        if(type(Set)!= set):
            logging.error("SetClass- Argument is not of type Set.")
            raise Exception("Sorry, the argument is not of type Set!!")
        else:
            self.setItem = Set
            
    """Return the count of items in the set"""       
    def length (self):
        count = 0
        for item in self.setItem:
            count = count + 1
        return count
        
    """Returns the index of the key"""   
    def index(self,searchKey):
        i = 0
        for item in self.setItem:
            if(item == searchKey):
                return i
             
            i= i+1
            
    """Return the maximum int value from the set"""
    def max(self):
        try:
            temp = 0
            for item in self.setItem:
                if(type(item)==int):
                    if(temp < item):
                        temp = item        
            return temp
        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an error in max().")
            
    """Return the difference between the Sets"""        
    def findDifference(self,secondSet):
        try:
            diff = set()
            for firstItem in self.setItem:                
                for secItem in secondSet:
                    if(firstItem == secItem):
                        break                
                else:
                    diff.add(secItem)

            for secItem in secondSet:
                for firstItem in self.setItem:
                    if(firstItem == secItem):
                        break                
                else:
                    diff.add(firstItem)

            return diff  
        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an error.")  
                
                
                
                
                
                