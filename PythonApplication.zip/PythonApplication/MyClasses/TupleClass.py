import logging

class TupleClass:
    def __init__(self, Tuple):
        logging.basicConfig(format='Date-Time : %(asctime)s : - %(message)s', level = logging.INFO, 
                            filename = 'AppLogs.log',filemode = 'w')
        if(type(Tuple)!= tuple):
            logging.error("TupleClass- Argument is not of type Tuple.")
            raise Exception("Sorry, the argument is not of type Tuple!!")
        else:
            self.tuple = Tuple
            
    """Return the count of items in the tuple"""       
    def length (self):
        count = 0
        for item in self.tuple:
            count = count + 1
        return count
        
    """Returns the index of the key"""   
    def index(self,searchKey):
        i = 0
        for item in self.tuple:
            if(item == searchKey):
                return i
             
            i= i+1
            
    """Return the maximum int value from the tuple"""
    def max(self):
        try:
            temp = 0
            for item in self.tuple:
                if(type(item)==int):
                    if(temp < item):
                        temp = item        
            return temp
        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an error in max().")
            
    """Return the minimum int value from the List"""        
    def min(self):
        try:
            if (self.length() == 0):
                return None
            
            temp = self.tuple[0]
            for item in self.tuple:
                if(type(item)==int and type(temp)==int):
                    if(temp > item):
                        temp = item   
                elif (type(temp)!=int):
                    temp = item 
            return temp
        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an error in min().")     