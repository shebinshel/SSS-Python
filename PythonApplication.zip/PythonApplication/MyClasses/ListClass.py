import logging
class ListClass:
    def __init__(self, List):
        
        logging.basicConfig(format='Date-Time : %(asctime)s : - %(message)s', level = logging.INFO, 
                            filename = 'AppLogs.log',filemode = 'w')
        if(type(List)!= list):
            logging.error("ListClass- Argument is not of type List.")
            raise Exception("Sorry, the argument is not of type List!!")
        else:
            self.list = List 
            
    """Length will return the count of items in the list"""
    def length(self):
        count = 0
        for item in self.list:
            count = count + 1
        return count
        
    """The list will be sorted in the asc order, only for int lists"""   
    def sort(self):
        try:
            sortList =[]                    
            while self.list:
                sortList.append(min(self.list))
                self.list.remove(min(self.list))

            return sortList

        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an error in the sort.")
            
    """Returns the list in the reverse order"""    
    def reverse(self):
        return self.list[::-1]      
        
    """Returns the item in the provided index position"""    
    def getItem(self, index):
        return self.list[index]      
    
    """Return the maximum int value from the List"""
    def max(self):
        try:
            temp = 0
            for item in self.list:
                if(type(item)==int):
                    if(temp < item):
                        temp = item        
            return temp
        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an error in max().")
            
    """Return the minimum int value from the List"""        
    def min(self):
        try:
            if (self.length() == 0):
                return None
            
            temp = self.list[0]
            for item in self.list:
                if(type(item)==int and type(temp)==int):
                    if(temp > item):
                        temp = item   
                elif (type(temp)!=int):
                    temp = item 
            return temp
        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an error in min().")
 
    """Concatenates the list with the argument list"""  
    def extend(self, newList):
        try:
            if(type(newList)!=list):
                logging.error("The argument should be a List")
                raise Exception("The argument should be a List")
            else:
                for item in newList:
                    self.list.append(item)
            return self.list
        except Exception as ex:
            logging.error(ex)
            raise Exception("Sorry, there is an errorin max().")           
            
            
            
 