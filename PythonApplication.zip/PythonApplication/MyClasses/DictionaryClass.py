import logging
from typing import Dict
class DictionaryClass:
    def __init__(self, Dictionary):
        logging.basicConfig(format='Date-Time : %(asctime)s : - %(message)s', level = logging.INFO, 
                            filename = 'AppLogs.log',filemode = 'w')

        if isinstance(Dictionary, Dict):
            self.dictionary = Dictionary
        else:
            logging.error("TupleClass- Argument is not of type Dictionary.")
            raise Exception("Sorry, the argument is not of type Dictionary!!")
            
            
    """Return the count of items in the dictionary"""       
    def length (self):
        count = 0
        for item in self.dictionary:
            count = count + 1
        return count
        
    """Returns all the keys"""
    def getValues(self):
        try:
            lst = []
            for item in self.dictionary:
                print(item)
                lst.append(item)
                
            return lst
        except Exception as ex:
            logging.error(ex)
    
    """Returns all the Values"""   
    def getKeys(self):
        try:
        
            lst = []
            for item in self.dictionary:
                lst.append(self.dictionary[item])
                
            return lst       
        except Exception as ex:
            logging.error(ex)   
            
    def get(self,searchKey):
        try:
            return self.dictionary[searchKey]
        except Exception as ex:
            logging.error(ex) 
        
        
